/*
 * File:   ecu2_main.c
 * Author: vedav
 *
 * Created on 6 July, 2026, 9:37 PM
 */

#include <xc.h>
#include <stdint.h>
#include "ecu2_sensors.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"

#define _XTAL_FREQ 20000000

void init_config(void)
{
    init_adc();
    init_digital_keypad();
    init_uart();
    init_can();
}

void main(void)
{
    uint16_t rpm;
    IndicatorStatus indicator;

    char rpm_data[5];
    char ind_data[3];

    init_config();

    while(1)
    {
        rpm = get_rpm();
        indicator = process_indicator();

        /* Convert RPM to ASCII */
        rpm_data[0] = (rpm / 1000) + '0';
        rpm_data[1] = ((rpm / 100) % 10) + '0';
        rpm_data[2] = ((rpm / 10) % 10) + '0';
        rpm_data[3] = (rpm % 10) + '0';
        rpm_data[4] = '\0';

        puts("\r\n-------------------------\r\n");

        puts("RPM : ");
        puts(rpm_data);
        puts("\r\n");

        puts("Indicator : ");

        switch(indicator)
        {
            case e_ind_left:

                puts("LEFT");

                ind_data[0] = 'L';
                ind_data[1] = 'I';

                LEFT_IND_ON();
                RIGHT_IND_OFF();

                __delay_ms(500);

                LEFT_IND_OFF();

                __delay_ms(500);

                break;

            case e_ind_right:

                puts("RIGHT");

                ind_data[0] = 'R';
                ind_data[1] = 'I';

                RIGHT_IND_ON();
                LEFT_IND_OFF();

                __delay_ms(500);

                RIGHT_IND_OFF();

                __delay_ms(500);

                break;

            case e_ind_hazard:

                puts("HAZARD");

                ind_data[0] = 'H';
                ind_data[1] = 'Z';

                LEFT_IND_ON();
                RIGHT_IND_ON();

                __delay_ms(500);

                LEFT_IND_OFF();
                RIGHT_IND_OFF();

                __delay_ms(500);

                break;

            default:

                puts("OFF");

                ind_data[0] = 'O';
                ind_data[1] = 'F';

                LEFT_IND_OFF();
                RIGHT_IND_OFF();

                break;
        }

        puts("\r\n");

        /* CAN Transmission */
        can_transmit(RPM_MSG_ID, (uint8_t *)rpm_data, 4);
        __delay_ms(20);

        can_transmit(INDICATOR_MSG_ID, (uint8_t *)ind_data, 2);
        __delay_ms(20);
    }
}