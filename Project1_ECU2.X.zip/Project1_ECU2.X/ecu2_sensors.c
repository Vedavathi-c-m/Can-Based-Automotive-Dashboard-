/*
 * File:   ecu2_sensors.c
 * Author: vedav
 *
 * Created on 6 July, 2026, 9:37 PM
 */

#include "ecu2_sensors.h"
#include "adc.h"
#include "digital_keypad.h"

volatile IndicatorStatus prev_ind_status = e_ind_off;
volatile IndicatorStatus cur_ind_status = e_ind_off;

uint16_t get_rpm(void)
{
    uint32_t adc_value;

    adc_value = read_adc(RPM_ADC_CHANNEL);

    return ((adc_value * 6000) / 1023);
}

IndicatorStatus process_indicator(void)
{
    unsigned char key;

    key = read_digital_keypad(STATE_CHANGE);

    switch(key)
    {
        case SWITCH1:
            cur_ind_status = e_ind_left;
            break;

        case SWITCH2:
            cur_ind_status = e_ind_right;
            break;

        case SWITCH3:
            cur_ind_status = e_ind_hazard;
            break;

        case SWITCH4:
            cur_ind_status = e_ind_off;
            break;

        default:
            break;
    }

    return cur_ind_status;
}