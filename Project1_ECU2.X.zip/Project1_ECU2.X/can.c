/*
 * File:   can.c
 * Author: vedav
 *
 * Created on 6 July, 2026, 9:34 PM
 */


#include <xc.h>

void main(void) {
    return;
}
