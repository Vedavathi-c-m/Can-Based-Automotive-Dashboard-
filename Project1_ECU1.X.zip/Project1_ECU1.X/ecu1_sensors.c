#include "ecu1_sensors.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"
#include "digital_keypad.h"
char gear_array[] = {'N','G1','G2','G3','G4','G5','R','C'};

uint16_t get_speed(void)
{
    uint32_t adc_value;

    adc_value = read_adc(SPEED_ADC_CHANNEL);

    return (uint16_t)((adc_value * 99) / 1023);
}

unsigned char get_gear_pos(void)
{
    static unsigned char count = 0;
    static unsigned char collision = 0;

    unsigned char key;

    key = read_digital_keypad(STATE_CHANGE);

    if(key == COLLISION)
    {
        count = 7;
        collision = 1;
    }
    else if(collision)
    {
        if((key == GEAR_UP) || (key == GEAR_DOWN))
        {
            count = 0;
            collision = 0;
        }
    }
    else if(key == GEAR_UP)
    {
        if(count < 6)
        {
            count++;
        }
    }
    else if(key == GEAR_DOWN)
    {
        if(count > 0)
        {
            count--;
        }
    }

    return gear_array[count];
}