/*
 * File:   ecu1_main.c
 * Author: vedav
 *
 * Created on 2 July, 2026, 9:04 AM
 */

#include <xc.h>
#include <stdint.h>
#include "adc.h"
#include "can.h"
#include "ecu1_sensors.h"
#include "msg_id.h"
#include "uart.h"

#define _XTAL_FREQ 20000000

void init_config(void)
{
    init_adc();
    init_digital_keypad();
    init_uart();
    init_can();
}

void main(void)
{
    uint16_t speed;
    unsigned char gear;

    char speed_data[3];
    char gear_data[3];

    init_config();

    while(1)
    {
        speed = get_speed();
        gear = get_gear_pos();
        speed_data[0] = (speed / 10) + '0';
        speed_data[1] = (speed % 10) + '0';
        speed_data[2] = '\0';
        if((gear >= '1') && (gear <= '5'))
        {
            gear_data[0] = 'G';
            gear_data[1] = gear;
        }
        else
        {
            gear_data[0] = gear;
            gear_data[1] = '\0';
        }
        puts("\r\n-----------------\r\n");

        puts("Speed : ");
        puts(speed_data);
        puts(" km/h\r\n");
        puts("Gear : ");
        if(gear_data[1] == '\0')
        {
            putch(gear_data[0]);
        }
        else
        {
            putch(gear_data[0]);
            putch(gear_data[1]);
        }
        puts("\r\n");
        can_transmit(SPEED_MSG_ID, (uint8_t *) speed_data, 2);
        __delay_ms(20);

        if (gear_data[1] == '\0') 
        {
            can_transmit(GEAR_MSG_ID, (uint8_t *) gear_data, 1);
        } 
        else 
        {
            can_transmit(GEAR_MSG_ID, (uint8_t *) gear_data, 2);
        }

        __delay_ms(20);

    }
}