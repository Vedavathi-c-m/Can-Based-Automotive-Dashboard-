/*
 * File:   message_handler.c
 * Author: vedav
 *
 * Created on 8 July, 2026, 10:31 AM
 */
#include <xc.h>
#include <string.h>

#include "message_handler.h"
#include "msg_id.h"
#include "can.h"
#include "clcd.h"

char flag = '0';

uint16_t msg_id;
uint8_t data[8];
uint8_t len;

void handle_speed_data(uint8_t *data, uint8_t len)
{
    char speed[3];

    if(len != 2)
        return;

    memcpy(speed, data, 2);
    speed[2] = '\0';

    clcd_print("SPD", LINE1(0));
    clcd_print("  ", LINE2(0));
    clcd_print(speed, LINE2(0));
}
void handle_gear_data(uint8_t *data, uint8_t len)
{
    char gear[3];

    if(len == 1)
    {
        gear[0] = data[0];
        gear[1] = '\0';
    }
    else if(len == 2)
    {
        gear[0] = data[0];
        gear[1] = data[1];
        gear[2] = '\0';
    }
    else
    {
        return;
    }

    clcd_print("GR", LINE1(4));
    clcd_print("  ", LINE2(4));
    clcd_print(gear, LINE2(4));
}


void handle_rpm_data(uint8_t *data, uint8_t len)
{
    char rpm[5];

    if(len != 4)
        return;

    memcpy(rpm, data, 4);
    rpm[4] = '\0';

    clcd_print("RPM", LINE1(7));
    clcd_print("    ", LINE2(7));
    clcd_print(rpm, LINE2(7));
}

void handle_indicator_data(uint8_t *data, uint8_t len)
{
    char ind[3];

    if(len != 2)
        return;

    memcpy(ind, data, 2);
    ind[2] = '\0';

    clcd_print("IND", LINE1(12));

    if(strcmp(ind, "LI") == 0)
    {
        flag = '1';
        clcd_print("<-", LINE2(12));
    }
    else if(strcmp(ind, "RI") == 0)
    {
        flag = '2';
        clcd_print("->", LINE2(12));
    }
    else if(strcmp(ind, "HZ") == 0)
    {
        flag = '3';
        clcd_print("HZ", LINE2(12));
    }
    else
    {
        flag = '0';
        clcd_print("--", LINE2(12));
    }
}


void process_canbus_data(void)
{
    can_receive(&msg_id, data, &len);

    if(len == 0)
        return;

    switch(msg_id)
    {
        case SPEED_MSG_ID:
            handle_speed_data(data, len);
            break;

        case GEAR_MSG_ID:
            handle_gear_data(data, len);
            break;

        case RPM_MSG_ID:
            handle_rpm_data(data, len);
            break;

        case INDICATOR_MSG_ID:
            handle_indicator_data(data, len);
            break;

        default:
            break;
    }
}


void update_indicator_led(void)
{
    static unsigned int delay = 0;
    static unsigned char led = 0;

    delay++;

    if(delay < 30000)
        return;

    delay = 0;
    led ^= 1;

    switch(flag)
    {
        case '1':      /* LEFT */

            PORTBbits.RB6 = 0;
            PORTBbits.RB7 = 0;

            PORTBbits.RB0 = led;
            PORTBbits.RB1 = led;

            break;

        case '2':      /* RIGHT */

            PORTBbits.RB0 = 0;
            PORTBbits.RB1 = 0;

            PORTBbits.RB6 = led;
            PORTBbits.RB7 = led;

            break;

        case '3':      /* HAZARD */

            PORTBbits.RB0 = led;
            PORTBbits.RB1 = led;
            PORTBbits.RB6 = led;
            PORTBbits.RB7 = led;

            break;

        default:       /* OFF */

            PORTBbits.RB0 = 0;
            PORTBbits.RB1 = 0;
            PORTBbits.RB6 = 0;
            PORTBbits.RB7 = 0;

            break;
    }
}

/*void __interrupt() ISR(void)
{
    if(TMR0IF)
    {
        TRISB0=0;
        TRISB1=0;
        TRISB2=0;
        TRISB3=0;
        
        PORTBbits.RB7=0;
        PORTBbits.RB6=0;
        PORTBbits.RB0=0;
        PORTBbits.RB1=0;
        TMR0IF = 0;
        TMR0 = 6;

        if(++count >= 20000)
        {
            count = 0;

            switch(flag)
            {
                case '1':

                    PORTBbits.RB6 = 0;
                    PORTBbits.RB7 = 0;

                    PORTBbits.RB0 ^= 1;
                    PORTBbits.RB1 ^= 1;
                    break;

                case '2':

                    PORTBbits.RB0 = 0;
                    PORTBbits.RB1 = 0;

                    PORTBbits.RB6 ^= 1;
                    PORTBbits.RB7 ^= 1;
                    break;

                case '3':

                    PORTBbits.RB0 ^= 1;
                    PORTBbits.RB1 ^= 1;
                    PORTBbits.RB6 ^= 1;
                    PORTBbits.RB7 ^= 1;
                    break;

                default:

                    PORTBbits.RB0 = 0;
                    PORTBbits.RB1 = 0;
                    PORTBbits.RB6 = 0;
                    PORTBbits.RB7 = 0;
                    break;
            }
        }
    }
}*/